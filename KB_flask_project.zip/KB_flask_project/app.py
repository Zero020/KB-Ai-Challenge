import cv2
import mediapipe as mp
import numpy as np
from flask import Flask, Response, render_template, request, redirect, url_for, session, jsonify
import time
import threading
import random
from queue import Queue
import requests
import PyPDF2
import warnings
from openai import OpenAI

warnings.filterwarnings("ignore", category=UserWarning, module='urllib3')

detection_data_queue = Queue()

app = Flask(__name__)


mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_face_mesh = mp.solutions.face_mesh

# 거짓말 탐지가 발생했는지 확인하는 Event 객체와 플래그
lie_detected_flag = threading.Event()
stop_thread = threading.Event()  # 쓰레드 종료 플래그

# 웹캠 리소스를 위한 전역 객체 생성
cap = None

# 거짓말 탐지 결과를 저장할 배열
detection_results = []  # Ensure detection_results is declared here


warnings.filterwarnings("ignore", category=UserWarning, module='urllib3')

detection_data_queue = Queue()

app = Flask(__name__)
app.secret_key = 'your_random_secret_key'

mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_face_mesh = mp.solutions.face_mesh

# 거짓말 탐지가 발생했는지 확인하는 Event 객체와 플래그
lie_detected_flag = threading.Event()
stop_thread = threading.Event()  # 쓰레드 종료 플래그

# 웹캠 리소스를 위한 전역 객체 생성
cap = None

# 예시 질문 목록
questions = [
    {
        "id": 1,
        "question": "고객님의 연령대는 어떻게 되시나요?",
        "options": ["19세 이하", "20대", "30대", "40대", "50대", "60대 이상"],
        "sub_questions": [
            {"id": 101, "question": "현재 연령대에서 주로 관심 있는 투자 상품은 무엇입니까?",
                "options": ["주식", "채권", "부동산", "가상화폐", "기타"]},
            {"id": 102, "question": "현재의 자산 포트폴리오는 어떤 형태입니까?", "options": [
                "주식 위주", "채권 위주", "부동산 위주", "현금 및 예금 위주", "기타"]},
            {"id": 103, "question": "향후 5년 내 자산 증가 목표는 어느 정도입니까?", "options": [
                "10% 이내", "20% 이내", "50% 이내", "100% 이내", "100% 초과"]},
            {"id": 104, "question": "현재 연령대에서 가장 우려하는 투자 리스크는 무엇입니까?",
                "options": ["시장 변동성", "금리 상승", "경기 침체", "정치적 불안", "기타"]},
            {"id": 105, "question": "현재 연령대에서 은퇴 계획은 어떻게 세우고 있습니까?", "options": [
                "10년 내 은퇴 계획", "20년 내 은퇴 계획", "은퇴 계획 없음", "이미 은퇴함", "기타"]}
        ]
    },
    {
        "id": 2,
        "question": "고객님의 연소득은 어떻게 되시나요?",
        "options": ["3천만원 이하", "5천만원 이하", "1억원 이하", "3억원 이하", "3억원 초과"],
        "sub_questions": [
            {"id": 201, "question": "연소득의 어느 비율을 투자에 사용하고 있습니까?", "options": [
                "10% 이하", "20% 이하", "30% 이하", "50% 이하", "50% 초과"]},
            {"id": 202, "question": "연소득 중 가장 큰 비중을 차지하는 수입원은 무엇입니까?",
                "options": ["근로소득", "사업소득", "투자소득", "연금소득", "기타"]},
            {"id": 203, "question": "연소득 변동에 따른 투자 계획 변경 빈도는 얼마나 됩니까?",
                "options": ["매월", "매분기", "매년", "3년마다", "거의 없음"]},
            {"id": 204, "question": "연소득 증대 목표는 어느 정도입니까?", "options": [
                "10% 이내", "20% 이내", "50% 이내", "100% 이내", "100% 초과"]},
            {"id": 205, "question": "연소득에 비해 현재 보유한 금융자산의 비율은 어느 정도입니까?",
                "options": ["10% 이하", "30% 이하", "50% 이하", "80% 이하", "80% 초과"]}
        ]
    },
    {
        "id": 3,
        "question": "다음 중 고객님의 수입원을 잘 나타내는 것을 선택해 주세요!",
        "options": ["현재 일정한 수입(근로소득, 사업소득, 임대소득)이 발생하고 있으며, 향후 현재 수준을 유지하거나 증가할것으로 예상",
                    "현재 일정한 수입(연금소득)이 발생하고 있으며, 향후 현재 수준을 유지할 것으로 예상",
                    "현재 일정한 수입이 발생하고 있으나, 향후 감소하거나 불안정할 것으로 예상",
                    "현재 일정한 수입이 없거나, 소액연금이 주 수입원임"],
        "sub_questions": [
            {"id": 301, "question": "수입원이 안정적인 경우, 추가적인 수입원을 마련할 계획이 있습니까?",
                "options": ["네", "아니요"]},
            {"id": 302, "question": "향후 수입원에 대한 가장 큰 리스크는 무엇입니까?",
                "options": ["직업 안정성", "경제 상황", "건강 문제", "시장 경쟁", "기타"]},
            {"id": 303, "question": "현재 수입원 외에 추가로 고려 중인 수입원은 무엇입니까?",
                "options": ["부업", "투자", "창업", "연금 증대", "기타"]},
            {"id": 304, "question": "수입원이 불안정할 경우, 자산 관리를 위해 어떤 조치를 취하고 있습니까?",
                "options": ["지출 절감", "추가 수입원 마련", "자산 매각", "대출 상환", "기타"]},
            {"id": 305, "question": "현재 수입원의 변화가 예상될 때, 투자 전략을 어떻게 조정합니까?",
                "options": ["공격적 투자로 전환", "방어적 투자로 전환", "투자 유지", "현금 보유 확대", "기타"]}
        ]
    },
    {
        "id": 4,
        "question": "고객님의 금융자산 중 투자 자금의 비중을 선택해 주세요!",
        "options": ["10% 이내", "30% 이내", "50% 이내", "80% 이내", "80% 초과"],
        "sub_questions": [
            {"id": 401, "question": "금융자산의 비중을 높이기 위한 계획이 있습니까?",
                "options": ["네", "아니요"]},
            {"id": 402, "question": "현재 금융자산의 구성은 어떻게 되어 있습니까?",
                "options": ["예금 및 적금", "주식", "채권", "펀드", "기타"]},
            {"id": 403, "question": "금융자산의 비중이 낮은 이유는 무엇입니까?", "options": [
                "부동산 비중이 높음", "현금 및 예금 비중이 높음", "투자 경험 부족", "시장 불안", "기타"]},
            {"id": 404, "question": "금융자산의 비중을 줄일 계획이 있습니까?",
                "options": ["네", "아니요"]},
            {"id": 405, "question": "현재 금융자산에서 주로 투자하고 있는 자산군은 무엇입니까?",
                "options": ["주식", "채권", "부동산 투자 신탁", "가상화폐", "기타"]}
        ]
    },
    {
        "id": 5,
        "question": "다음 중 고객님의 투자해본 금융상품을 모두 선택해 주세요!",
        "options": ["은행 예적금, 국채, 지방채, 보증채, MMF, CMA 등",
                    "채권형펀드, 금융채, 신용도가 높은 회사채, 원금보장형 ELS/ELF 등",
                    "혼합형 펀드, 신용도가 중간 등급인 회사채, 원금의 일부만 보장되는 ELS/ELF 등",
                    "주식형 펀드, 신용도가 낮은 회사채, 원금이 보장되지 않는 ELS/ELF 등",
                    "파생상품 펀드, 주식 신용거래, ELW, 선물·옵션 등"],
        "sub_questions": [
            {"id": 501, "question": "가장 최근에 투자한 상품은 무엇입니까?", "options": [
                "은행 예적금", "채권형 펀드", "혼합형 펀드", "주식형 펀드", "파생상품"]},
            {"id": 502, "question": "투자 경험 중 가장 큰 성공 사례는 무엇입니까?",
                "options": ["주식 투자", "채권 투자", "부동산 투자", "펀드 투자", "기타"]},
            {"id": 503, "question": "투자 경험 중 가장 큰 실패 사례는 무엇입니까?",
                "options": ["주식 투자", "채권 투자", "부동산 투자", "펀드 투자", "기타"]},
            {"id": 504, "question": "투자 경험이 부족하다고 느낄 때, 주로 참고하는 정보원은 무엇입니까?",
                "options": ["금융 전문가", "금융 서적 및 잡지", "인터넷 및 SNS", "가족 및 친구", "기타"]},
            {"id": 505, "question": "현재 투자하고 있는 자산 중 가장 만족스러운 자산은 무엇입니까?",
                "options": ["주식", "채권", "부동산", "펀드", "기타"]}
        ]
    },
    {
        "id": 6,
        "question": "파생상품, 파생결합증권(ELS, ELF) 또는 파생상품투자펀드(레버리지펀드 등) 등 해당 상품에 투자한 경험이 있으신가요?",
        "options": ["1년 미만(투자경험이 없으신 경우 포함)", "1년 이상 ~ 3년 미만", "3년 이상"],
        "sub_questions": [
            {"id": 601, "question": "파생상품에 투자한 이유는 무엇입니까?", "options": [
                "고수익 추구", "포트폴리오 다변화", "위험 관리", "단기 투자", "기타"]},
            {"id": 602, "question": "파생상품 투자 시 가장 큰 우려 사항은 무엇입니까?",
                "options": ["시장 변동성", "복잡한 구조", "높은 수수료", "원금 손실 위험", "기타"]},
            {"id": 603, "question": "파생상품 투자에서 얻은 가장 큰 교훈은 무엇입니까?", "options": [
                "시장 타이밍의 중요성", "리스크 관리의 중요성", "전문가 조언의 중요성", "자기주도 학습의 중요성", "기타"]},
            {"id": 604, "question": "파생상품 투자에 대한 정보를 주로 어디서 얻습니까?", "options": [
                "금융 전문가", "금융 서적 및 잡지", "인터넷 및 SNS", "가족 및 친구", "기타"]},
            {"id": 605, "question": "파생상품 투자를 늘릴 계획이 있습니까?",
                "options": ["네", "아니요"]}
        ]
    },
    {
        "id": 7,
        "question": "고객님의 금융투자상품에 대한 이해도는 어느 정도입니까?",
        "options": ["매우 높음", "높음", "낮음", "매우 낮음"],
        "sub_questions": [
            {"id": 701, "question": "금융투자상품 이해도를 높이기 위해 어떤 방법을 사용합니까?", "options": [
                "금융 전문가 상담", "금융 서적 및 잡지 읽기", "온라인 강의 수강", "세미나 및 워크숍 참석", "기타"]},
            {"id": 702, "question": "가장 관심 있는 금융투자상품은 무엇입니까?",
                "options": ["주식", "채권", "펀드", "파생상품", "기타"]},
            {"id": 703, "question": "금융투자상품 이해도를 높이는 데 가장 큰 어려움은 무엇입니까?",
                "options": ["복잡한 용어", "시간 부족", "정보의 부족", "경험 부족", "기타"]},
            {"id": 704, "question": "금융투자상품에 대한 지식 습득을 위해 주로 사용하는 정보원은 무엇입니까?",
                "options": ["금융 전문가", "금융 서적 및 잡지", "인터넷 및 SNS", "가족 및 친구", "기타"]},
            {"id": 705, "question": "금융투자상품에 대한 이해도가 높아졌다고 느낄 때, 어떤 변화가 있었습니까?", "options": [
                "투자 수익 증가", "리스크 관리 능력 향상", "투자 포트폴리오 다변화", "투자 자신감 증가", "기타"]}
        ]
    },
    {
        "id": 8,
        "question": "고객님의 금융투자상품 가입 목적을 선택해 주세요!",
        "options": ["자산 증식 (여유 자금 투자)", "노후 자금 마련", "목적 자금 마련(결혼자금, 주택구입자금 등)", "사용 예정 자금 단기 운용(전세금, 임차보증금 등)"],
        "sub_questions": [
            {"id": 801, "question": "투자 목적 달성을 위해 현재 진행 중인 전략은 무엇입니까?",
                "options": ["장기 투자", "단기 투자", "포트폴리오 다변화", "저위험 투자", "고위험 투자"]},
            {"id": 802, "question": "투자 목적 달성을 위해 목표 기간은 얼마입니까?",
                "options": ["1년 이하", "1~3년", "3~5년", "5~10년", "10년 이상"]},
            {"id": 803, "question": "투자 목적 달성을 위해 가장 중요하게 생각하는 요소는 무엇입니까?",
                "options": ["안정성", "수익성", "유동성", "세제 혜택", "기타"]},
            {"id": 804, "question": "투자 목적이 변경된 적이 있습니까?",
                "options": ["네", "아니요"]},
            {"id": 805, "question": "투자 목적 달성 후 다음 목표는 무엇입니까?", "options": [
                "자산 유지", "추가 자산 증식", "다른 목적 자금 마련", "은퇴 준비", "기타"]}
        ]
    },
    {
        "id": 9,
        "question": "고객님께서 투자하실 자금의 예상투자기간을 선택해 주세요!",
        "options": ["투자기간과 상관없이 만기일까지 보유", "3년 이상", "3년 미만", "1년 미만", "6개월 미만"],
        "sub_questions": [
            {"id": 901, "question": "투자기간 동안 예상되는 주요 리스크는 무엇입니까?",
                "options": ["시장 변동성", "금리 변동", "경제 불황", "정치적 불안", "기타"]},
            {"id": 902, "question": "투자기간 동안 목표 수익률은 어느 정도입니까?", "options": [
                "5% 이하", "10% 이하", "20% 이하", "50% 이하", "50% 이상"]},
            {"id": 903, "question": "투자기간 동안 자산 분배 전략은 무엇입니까?", "options": [
                "주식 위주", "채권 위주", "혼합형 펀드 위주", "부동산 투자 위주", "기타"]},
            {"id": 904, "question": "투자기간 동안 예상되는 주요 지출 항목은 무엇입니까?",
                "options": ["주택 구입", "교육비", "의료비", "여행 및 여가비", "기타"]},
            {"id": 905, "question": "투자기간 동안 자산 포트폴리오 재조정 빈도는 얼마나 됩니까?",
                "options": ["매월", "매분기", "매년", "3년마다", "거의 없음"]}
        ]
    },
    {
        "id": 10,
        "question": "다음 중 현재 투자하는 자금에 대하여 고객님의 기대하는 수익과 감내 할 수 있는 손실은 어느 정도인가요?",
        "options": ["기대수익이 높다면 시장 상황에 따라 원금을 초과하는 손실을 감내 할 수 있다.",
                    "기대수익이 높다면 20% ~ 100% 의 손실을 감내 할 수 있다.",
                    "원하는 수준의 수익을 기대 할 수 있다면 20% 이내의 손실을 감내 할 수 있다.",
                    "일정 수준의 수익을 기대 할 수 있다면 경미한 수준의 손실을 감내 할 수 있다.",
                    "투자원금 보전을 추구한다."],
        "sub_questions": [
            {"id": 1001, "question": "투자 손실을 경험한 적이 있습니까?",
                "options": ["네", "아니요"]},
            {"id": 1002, "question": "손실 발생 시 가장 먼저 취하는 행동은 무엇입니까?",
                "options": ["즉시 매도", "추가 매수", "상황 지켜보기", "전문가 상담", "기타"]},
            {"id": 1003, "question": "기대 수익률을 결정할 때 고려하는 요소는 무엇입니까?",
                "options": ["시장 상황", "투자 자산 특성", "과거 투자 성과", "전문가 의견", "기타"]},
            {"id": 1004, "question": "손실을 감내할 수 있는 최대 기간은 어느 정도입니까?",
                "options": ["6개월 이하", "1년 이하", "3년 이하", "5년 이하", "5년 이상"]},
            {"id": 1005, "question": "기대 수익이 예상보다 낮아질 경우, 어떻게 대응할 계획입니까?",
                "options": ["즉시 매도", "추가 매수", "상황 지켜보기", "전문가 상담", "기타"]}
        ]
    }
]

# 눈 깜빡임과 관련된 랜드마크 인덱스 (좌, 우 눈)
LEFT_EYE_LANDMARKS = [33, 133, 158, 153, 160, 144]  # 왼쪽 눈의 특정 랜드마크
RIGHT_EYE_LANDMARKS = [362, 263, 387, 373, 385, 380]  # 오른쪽 눈의 특정 랜드마크

# 입술 떨림 감지용 랜드마크 인덱스
LIPS_LANDMARKS = [61, 78, 185, 191]

# 입술 떨림 감지용 랜드마크 인덱스
LEFT_CENTER = [159, 145]
RIGHT_CENTER = [386, 374]

# Eye Aspect Ratio (EAR)를 계산하는 함수


def calculate_ear(eye_landmarks, landmarks, width, height):
    vertical_1 = np.linalg.norm(
        np.array([landmarks[eye_landmarks[1]].x * width, landmarks[eye_landmarks[1]].y * height]) -
        np.array([landmarks[eye_landmarks[5]].x * width,
                 landmarks[eye_landmarks[5]].y * height])
    )
    vertical_2 = np.linalg.norm(
        np.array([landmarks[eye_landmarks[2]].x * width, landmarks[eye_landmarks[2]].y * height]) -
        np.array([landmarks[eye_landmarks[4]].x * width,
                 landmarks[eye_landmarks[4]].y * height])
    )
    horizontal = np.linalg.norm(
        np.array([landmarks[eye_landmarks[0]].x * width, landmarks[eye_landmarks[0]].y * height]) -
        np.array([landmarks[eye_landmarks[3]].x * width,
                 landmarks[eye_landmarks[3]].y * height])
    )
    ear = (vertical_1 + vertical_2) / (2.0 * horizontal)
    return ear


def lie_detection(start_time):
    global cap
    if cap is None:
        cap = cv2.VideoCapture(0)
    tmp_blink_cnt = 0
    blink_count = 0
    tmp_lip_mvm_cnt = 0
    lip_movement_count = 0

    with mp_face_mesh.FaceMesh(
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5) as face_mesh:
        while True:
            success, frame = cap.read()
            if not success:
                break

            image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(image)

            if results.multi_face_landmarks:
                for face_landmarks in results.multi_face_landmarks:
                    height, width, _ = image.shape
                    landmarks = face_landmarks.landmark

                    # 눈 깜빡임 감지
                    left_ear = calculate_ear(
                        LEFT_EYE_LANDMARKS, landmarks, width, height)
                    right_ear = calculate_ear(
                        RIGHT_EYE_LANDMARKS, landmarks, width, height)
                    avg_ear = (left_ear + right_ear) / 2.0

                    if avg_ear < 0.786:

                        if tmp_blink_cnt > 9:
                            # print("눈떨림")
                            blink_count += 1
                            tmp_blink_cnt = 0
                        else:
                            tmp_blink_cnt += 1

                    # 입술 떨림 감지
                    lip_movement = np.mean([np.linalg.norm(
                        np.array([landmarks[LIPS_LANDMARKS[i]].x, landmarks[LIPS_LANDMARKS[i]].y]) -
                        np.array([landmarks[LIPS_LANDMARKS[i + 1]].x, landmarks[LIPS_LANDMARKS[i + 1]].y]))
                        for i in range(len(LIPS_LANDMARKS) - 1)])

                    if lip_movement > 0.0065:
                        # print("입술 떨림")
                        if tmp_lip_mvm_cnt > 4:
                            # print("입술 떨림")
                            lip_movement_count += 1
                        else:
                            tmp_lip_mvm_cnt += 1

                    # 거짓말 탐지 징후 확인
                    if blink_count > 5 or lip_movement_count > 5:
                        detection_result = "True"
                        detection_results.append(detection_result)
                        blink_count = 0
                        lip_movement_count = 0
                    else:
                        detection_result = "False"
                        detection_results.append(detection_result)

    # 거짓말 탐지 결과를 저장할 배열
    detection_results = []

# 예시로 간단히 true/false 값을 랜덤으로 생성하여 신뢰도 측정


def calculate_trustability():
    return random.choice([True, False])


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/start-survey')
def start_survey():
    # 설문조사 URL을 지정합니다.
    session['results'] = []
    session['current_question'] = 0
    session['asked_questions'] = []

    elapsed_time = 0  # 초기화
    true_count = 0  # 초기화

    # 거짓말 탐지 쓰레드 시작 (이미 실행 중인지 확인)
    if not lie_detected_flag.is_set():
        start_time = time.time()
        lie_detected_flag.clear()  # 플래그 초기화
        stop_thread.clear()  # 종료 플래그 초기화
        detection_thread = threading.Thread(
            target=lie_detection, args=(start_time,), daemon=True)
        detection_thread.start()

    return redirect(url_for('survey'))


@app.route('/survey', methods=['GET', 'POST'])
def survey():
    current_question_index = session.get('current_question', 0)

    if request.method == 'POST':
        selected_option = request.form.get('answer')
        if current_question_index >= len(questions):
            # print("초과!!!!!!")
            stop_thread.set()  # 쓰레드 종료
            return redirect(url_for('results'))

        session['results'].append({
            "question_id": questions[current_question_index]['id'],
            "selected_option": selected_option,
        })

        # 이미 물어본 질문은 다시 물어보지 않도록 처리
        session['asked_questions'].append(
            questions[current_question_index]['id'])

        print(detection_results.count("True"), len(detection_results)*0.01)

        if detection_results.count("True") > len(detection_results)*0.01:
            lie_detected_flag.set()
            print("거짓말 감지~~~~~~~~~~~~~~")
            sub_questions = questions[current_question_index].get(
                'sub_questions', [])
            for sub_question in sub_questions:
                if sub_question['id'] not in session['asked_questions']:
                    session['asked_questions'].append(sub_question['id'])
                    questions.insert(current_question_index + 1, sub_question)
                    break

        detection_results.clear()
        lie_detected_flag.clear()

        current_question_index += 1
        session['current_question'] = current_question_index

    if current_question_index >= len(questions):
        stop_thread.set()  # 쓰레드 종료
        return redirect(url_for('results'))

    current_question = questions[current_question_index]
    return render_template('survey.html', question=current_question)


@app.route('/results')
def results():
    global cap
    if cap:
        cap.release()  # 설문조사 종료 시 웹캠 해제
        cap = None

    score = 0
    for i in session['results']:
        if i['question_id'] > 100:
            q_id1 = i['question_id'] // 100 - 1
            sub_answer = i['question_id'] % 100 - 1
            option_arr1 = questions[q_id1]["sub_questions"][sub_answer]["options"]
            score += option_arr1.index(i['selected_option']) + 1
        else:
            q_id2 = i['question_id'] - 1
            option_arr2 = questions[q_id2]["options"]
            score += option_arr2.index(i['selected_option']) + 1

    # Recommended products and their PDF links
    recommended_products = [
        {
            "id": 1,
            "name": "[ISA] 개인종합자산관리계좌 중개형 약관",
            "url": "https://fdata.kbsec.com/agree/goods47.pdf"
        },
        {
            "id": 2,
            "name": "[펀드] 청년형 장기집합투자증권저축약관",
            "url": "https://fdata.kbsec.com/agree/goods77.pdf"
        },
        {
            "id": 3,
            "name": "[저축] 재형저축약관",
            "url": "https://fdata.kbsec.com/agree/goods15.pdf"
        }
    ]

    return render_template('results.html', score=score, products=recommended_products)


@app.route('/view_pdf/<int:product_id>')
def view_pdf(product_id):
    pdf_urls = {
        1: "https://fdata.kbsec.com/agree/goods47.pdf",
        2: "https://fdata.kbsec.com/agree/goods77.pdf",
        3: "https://fdata.kbsec.com/agree/goods15.pdf"
    }

    product_names = {
        1: "[ISA] 개인종합자산관리계좌 중개형 약관",
        2: "[펀드] 청년형 장기집합투자증권저축약관",
        3: "[저축] 재형저축약관"
    }

    pdf_url = pdf_urls.get(product_id, "#")
    title = product_names.get(product_id, "Product PDF")

    return render_template('pdf_viewer.html', title=title, pdf_url=pdf_url, product_id=product_id)


# OpenAI API Initialization
api_key = 'sk-T1vP54mBZMCtNrvca9RhWqFzslsfdXmz0Ex_65wn0VT3BlbkFJl1eRIFeMEXEXnVsKfu9-AYYPeB3hKMrz7BbtGbJHgA'
client = OpenAI(api_key=api_key)


def generate_dialogue(prompt, model="gpt-3.5-turbo-0125", max_tokens=4000, temperature=0.7, top_p=1.0, frequency_penalty=0.0, presence_penalty=0.0):
    response = client.chat.completions.create(
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": f"내용을 읽고 중요한 내용만 요약해줘:\n{prompt}"}
        ],
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
    )
    return response


def download_pdf(url, file_path):
    """PDF 파일을 인터넷에서 다운로드하는 함수"""
    response = requests.get(url)
    with open(file_path, "wb") as file:
        file.write(response.content)


def read_pdf(file_path):
    """PDF 파일을 읽어서 텍스트를 반환하는 함수"""
    with open(file_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
    return text


@app.route('/summarize_pdf/<int:product_id>')
def summarize_pdf(product_id):
    """PDF URL을 통해 PDF를 다운로드하고 요약하여 반환하는 엔드포인트"""
    pdf_urls = {
        1: "https://fdata.kbsec.com/agree/goods47.pdf",
        2: "https://fdata.kbsec.com/agree/goods77.pdf",
        3: "https://fdata.kbsec.com/agree/goods15.pdf"
    }
    pdf_url = pdf_urls.get(product_id)

    if not pdf_url:
        return jsonify({"error": "Invalid product ID"}), 400

    file_path = f"static/downloaded_file_{product_id}.pdf"
    download_pdf(pdf_url, file_path)
    text = read_pdf(file_path)
    dialogue = generate_dialogue(text)

    summary = ""
    for choice in dialogue.choices:
        message_content = choice.message.content.strip()
        messages = message_content.split('\n\n')
        for message in messages:
            summary += message + "\n\n"

    total_tokens = dialogue.usage.total_tokens
    return jsonify({"summary": summary})


if __name__ == '__main__':
    app.run(debug=True)
